'use strict';
angular.module('app').controller('LoginCtrl', function () {
});